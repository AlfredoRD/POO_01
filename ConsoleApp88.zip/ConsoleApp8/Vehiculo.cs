﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    public class Vehiculo
    {
        private string Marca ;
        private string Modelo;

        public void SetVehiculo(string Mar, string Mod)
        {
            this.Marca = Mar;
            this.Modelo = Mod;
        }
            public void Vervehiculo()

            {
            Console.WriteLine("El vehiculo es " + Marca + " modelo " + Modelo);
                Console.ReadKey();
            }
       }
    }
          
