﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    class Mostrarvehiculo
    {
        static void Main(string[] args)
        {
            Vehiculo coche1 = new Vehiculo();
            string mar;
            string mod;
          
            Console.WriteLine("Ingrese la marca de su vehiculo");
            mar = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Ingrese el modelo de su vehiculo");
            mod = Console.ReadLine();
            Console.Clear();
            coche1.SetVehiculo(mar, mod);
            coche1.Vervehiculo();
            Console.Clear();
            Vehiculo coche2 = new Vehiculo();   
            Console.WriteLine("Ingrese la marca de su vehiculo");
            mar = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Ingrese el modelo de su vehiculo");
            mod = Console.ReadLine();
            Console.Clear();
            coche2.SetVehiculo(mar, mod);
            coche2.Vervehiculo();
            Console.ReadKey();
            Console.Clear();

            
        }
    }
}
